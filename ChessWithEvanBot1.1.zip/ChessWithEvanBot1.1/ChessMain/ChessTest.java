package ChessMain;

public class ChessTest {
    public static void main(String[] args) {
        ChessCoordinator test = new ChessCoordinator();
    }
}
