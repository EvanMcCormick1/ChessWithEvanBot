package AI;

import ChessMain.ChessCoordinator;

public class PVP extends ChessAI{

    public PVP(ChessCoordinator cc){
        super(cc);
    }

    public void makeMove(){

    }
    
}
